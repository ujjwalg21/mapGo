import React from 'react'

const hostHome = () => {
  return (
    <div>
      
    </div>
  )
}

export default hostHome
